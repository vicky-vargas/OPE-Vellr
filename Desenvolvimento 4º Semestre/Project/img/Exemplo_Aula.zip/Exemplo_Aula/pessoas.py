from flask import Flask, request


app = Flask(__name__)

#criar um servidor de pessoas, que me diz quem está cadastrado
#tb criar um servidor de chat, para as pessoas poderem conversar
#o servidor de chat vai ter que consultar pra ver se a pessoa existe

pessoas = ['Everson', 'Elias', 'Brando']

#fazer um endpoint (uma url) /pessoas/Elias, que me diz true se Elias
#esta cadastrado e false se ela nao esta

def verifica_nome(nome):
    return nome in pessoas
        
@app.route('/pessoas/<nome>')#string é um padrao, nao precisa por tipo
def pessoa_existe(nome):
    return {'encontrado':verifica_nome(nome),
    'isok': True}
'''
# O que quer dizer idempotente?
# 1.O que é um efeito colateral?
#   Todo request sempre volta um arquivo. A questão é, será que acontece
#   alguma outra coisa? Ex: salvo no banco, deleto, mando um email, faco uma
#   cobrança de cartao de credito
# 2. Itempotente quer dizer se eu chamar 20 vezes, o efeito colateral ocorre
#   apenas uma vez
  Essa minha funcao ai de baixo, está idempotente? Está!
  Eu poderia trocar o verbo http para PUT
  Put parece MUITO o POST, a diferença é que quando eu uso PUT
  no meu servidor, estou prometendo pro usuario que o pedido é idempotente
  
'''
@app.route('/pessoas/', methods=['PUT'])
def cria_pessoa():
    #espero receber um dicionario. Como eu pego?
    dic_enviado = request.json
    #verificar se ele tem a chave nome. 
    if 'nome' not in dic_enviado: #decidi retornar 400
        return {'erro':'chave nome nao consta no dici enviado','isok': False},400
    if verifica_nome(dic_enviado['nome']):
        return {'erro':'esse nome de usuario ja foi usado','isok': False},409
    pessoas.append(dic_enviado['nome'])
    return {'pessoas':pessoas,'isok': True}    

    # Se nao tiver, quero dar um cod status. Qual? 404 500 400 409
    # 500 seria se o erro fosse no servidor, se o bd caiu ou se tem algum problema local
    # "usuario, vc nao fez nada de errado" -> nao é o caso
    # 404: Usuario tentou acessar uma pagina/recurso que nao existe
    # 400: Usuario errou de alguma forma -> serve!
    #faço a inserção em si

if __name__ == '__main__':
    app.run(host = 'localhost', port = 5002, debug = True) 
