from flask import Flask, request
import requests as banana

app = Flask(__name__)

mensagens = [
    {'nome':'Pablo', 'mensagem':'Ubuntu é top'},
    {'nome':'Lucas', 'mensagem':'é msm'},
    {'nome':'Guilherme', 'mensagem':'tem que mudar a porta!'}
]

#url que retorna todas as mensagens
@app.route("/mensagens")
def get_mensagens():
    return {'mensagens': mensagens, 'isok': True}

#outra url, com POST, para criar uma msg nova
@app.route("/mensagens", methods=['POST'])
def insere_mensagem():
    dic_enviado = request.json #pego o dicionario
    chave = 'nome'
    if chave not in dic_enviado:
        return {'erro':f'dici nao contem chave {chave}','isok': False}, 400
    chave = 'mensagem'
    if chave not in dic_enviado:
        return {'erro':f'dici nao contem chave {chave}','isok': False}, 400
    mensagens.append(dic_enviado) #inserir na lista
    #verifica se o usuário que está mandando msg é um usuário registado
    #(abrir uma conexao pro pessoas.py)
    nome = dic_enviado['nome']
    r=banana.get(f"http://localhost:5002/pessoas/{nome}")
    #if pessoa zoada
    if not r.json()['encontrado']:
        return {'erro':f'pessoa enviada nao tem conta','isok': False}, 400
    return {'mensagens': mensagens, 'isok': True}


if __name__ == '__main__':
    app.run(host = 'localhost', port = 5003, debug = True) 
