>>> import requests
>>> requests.get('http://localhost:5002
<Response [200]>
>>> a=requests.get('http://localhost:50
>>> print(a)
<Response [200]>
>>> a.json
<bound method Response.json of <Respons
>>> a.json()
{'encontrado': True}
>>> a=requests.get('http://localhost:50
>>> a.json()
{'encontrado': False}
>>> a=requests.post('http://localhost:5002/pessoas/',json={'nome':'Brando'})
>>> a.status_code
200
>>> a.text
'{\n  "pessoas": [\n    "Everson", \n    "Elias", \n    "Brando", \n    "Brando"\n  ]\n}\n'
>>> a.json()
{'pessoas': ['Everson', 'Elias', 'Brando', 'Brando']}
>>> a=requests.post('http://localhost:5002/pessoas/',json={'nome':'Victoria'}) 

>>> r.status_code
405
>>> r=requests.put('http://localhost:50
>>> r.status_code
500
>>> r=requests.put('http://localhost:5002/pessoas/', json={'nome':'Eduardo'})
>>> r.status_code
200
>>> r.json()
{'isok': True, 'pessoas': ['Everson', 'Elias', 'Brando', 'Eduardo']}
>>> a=requests.post('http://localhost:5003/mensagens',json={'nome':'Eduardo', 'mensagem':"Let's code"})
>>> a.status_code
200
>>> a.json()
{'isok': True, 'mensagens': [{'mensagem': 'Ubuntu é top', 'nome': 'Pablo'}, {'mensagem': 'é msm', 'nome': 'Lucas'}, {'mensagem': 'tem que mudar a porta!', 'nome': 'Guilherme'}, {'mensagem': "Let's code", 'nome': 'Eduardo'}, {'mensagem': "Let's code", 'nome': 'Eduardo'}]}

